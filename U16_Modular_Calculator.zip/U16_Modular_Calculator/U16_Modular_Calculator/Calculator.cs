﻿using System;

namespace U16_Modular_Calculator
{
    internal class Calculator
    {
        public Calculator()
        {
        }

        internal object Add(double inputOne, double inputTwo)
        {
            throw new NotImplementedException();
        }

        internal object Subtract(double inputOne, double inputTwo)
        {
            throw new NotImplementedException();
        }

        internal object Multiply(double inputOne, double inputTwo)
        {
            throw new NotImplementedException();
        }

        internal object Divide(double inputOne, double inputTwo)
        {
            throw new NotImplementedException();
        }
    }
}